function CalcularMontante(){

    let capital = document.getElementById('capital').value;
    let tempo = document.getElementById('tempo').value;
    let taxa = document.getElementById('taxa').value;

    let M = (capital*(1+taxa)**tempo);

    var resultado = document.getElementById('resultado');
    resultado.innerText = M;
    
}
