function CalcularMedida(){
    let medida = document.getElementById('medida').value;
    let unidade = document.getElementById('unidade').value;
    
   if unidade = milha{

   }

    var resultado = document.getElementById('resultado');
    resultado.innerText = juros;
    
}
